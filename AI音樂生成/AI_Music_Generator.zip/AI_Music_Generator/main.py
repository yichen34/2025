# main.py
"""
啟動本地端 Gradio 介面：
    python main.py
"""

from src.interface import launch_app


if __name__ == "__main__":
    launch_app()
