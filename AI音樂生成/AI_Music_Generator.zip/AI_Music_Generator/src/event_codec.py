# event_codec.py
# 定義事件種類、編碼與解碼功能

# ---------------------------
# 事件類別與 Token 區間定義
# ---------------------------

# Note-On: 0~127
NOTE_ON_BASE = 0
NOTE_ON_RANGE = 128  # 音符 0~127

# Note-Off: 128~255
NOTE_OFF_BASE = 128
NOTE_OFF_RANGE = 128

# Velocity: 256~256+31
VELOCITY_BASE = 256
VELOCITY_RANGE = 32  # 量化後 32 階

# Time-Shift: 288~288+127
TIME_SHIFT_BASE = 288
TIME_SHIFT_RANGE = 128  # 允許最多 shift 128 ticks

# event_codec.py 中，保留前面 NOTE_ON_BASE 等定義
# 這一段用來定義 Special Tokens 與總 vocab 數

# 基本事件總量
BASE_VOCAB = (
    NOTE_ON_RANGE +
    NOTE_OFF_RANGE +
    VELOCITY_RANGE +
    TIME_SHIFT_RANGE
)

# 將 PAD / BOS / EOS / MASK 放在 vocab 的最後面
PAD = BASE_VOCAB          # 例如 416
BOS = BASE_VOCAB + 1      # 417
EOS = BASE_VOCAB + 2      # 418
MASK = BASE_VOCAB + 3     # 419

SPECIAL_TOKENS = [PAD, BOS, EOS, MASK]


# ---------------------------
# 事件封裝工具
# ---------------------------

def note_on_event(pitch: int):
    return NOTE_ON_BASE + pitch


def note_off_event(pitch: int):
    return NOTE_OFF_BASE + pitch


def velocity_event(level: int):
    return VELOCITY_BASE + level


def time_shift_event(shift: int):
    return TIME_SHIFT_BASE + shift


# ---------------------------
# 解碼工具：token → 事件
# ---------------------------

def decode_token(token: int):
    """把 token 轉回事件格式 (type, value)"""

    if token in SPECIAL_TOKENS:
        return ("special", token)

    # Note-On
    if NOTE_ON_BASE <= token < NOTE_ON_BASE + NOTE_ON_RANGE:
        return ("note_on", token - NOTE_ON_BASE)

    # Note-Off
    if NOTE_OFF_BASE <= token < NOTE_OFF_BASE + NOTE_OFF_RANGE:
        return ("note_off", token - NOTE_OFF_BASE)

    # Velocity
    if VELOCITY_BASE <= token < VELOCITY_BASE + VELOCITY_RANGE:
        return ("velocity", token - VELOCITY_BASE)

    # Time-Shift
    if TIME_SHIFT_BASE <= token < TIME_SHIFT_BASE + TIME_SHIFT_RANGE:
        return ("time_shift", token - TIME_SHIFT_BASE)

    # 無效 token
    return ("unknown", token)


# 總 token 數量（事件 + 特殊符號）
TOTAL_TOKENS = BASE_VOCAB + len(SPECIAL_TOKENS)
