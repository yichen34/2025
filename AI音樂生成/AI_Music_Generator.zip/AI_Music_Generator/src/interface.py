# src/interface.py

from pathlib import Path
import subprocess
import shutil
from typing import Optional, Tuple

import gradio as gr
import pretty_midi

from .generate import generate_and_save_midi


# -------------------------------------------------------------
# SoundFont 路徑（請確認存在）
# -------------------------------------------------------------
SOUNDFONT_PATH = Path(
    r"C:\Users\Owner\OneDrive\桌面\專題\AI_Music_Generator\soundfonts\FluidR3_GM.sf2"
)


# -------------------------------------------------------------
# MIDI 後處理（音域限制、C 大調、多聲部限制、最短音長）
# -------------------------------------------------------------
def postprocess_midi_file(
    midi_path: Path,
    max_polyphony: Optional[int] = None,
    min_note_length: float = 0.0,
    pitch_low: Optional[int] = None,
    pitch_high: Optional[int] = None,
    enforce_c_major: bool = False,
) -> None:

    if not midi_path.exists():
        print(f"[⚠ 警告] 找不到 MIDI 檔案：{midi_path}")
        return

    print(f"[資訊] 開始對 {midi_path} 做後處理 ...")

    pm = pretty_midi.PrettyMIDI(str(midi_path))
    c_major_pcs = {0, 2, 4, 5, 7, 9, 11}

    for inst in pm.instruments:
        notes = sorted(inst.notes, key=lambda n: n.start)
        result = []

        for n in notes:
            pitch = n.pitch

            # 音域限制（以八度調整）
            if pitch_low is not None or pitch_high is not None:
                if pitch_low is not None:
                    while pitch < pitch_low:
                        pitch += 12
                if pitch_high is not None:
                    while pitch > pitch_high:
                        pitch -= 12
                if pitch_low is not None and pitch < pitch_low:
                    continue
                if pitch_high is not None and pitch > pitch_high:
                    continue

            # 強制 C 大調
            if enforce_c_major:
                pc = pitch % 12
                if pc not in c_major_pcs:
                    best_pitch = pitch
                    best_dist = 999
                    for tgt in c_major_pcs:
                        for offset in range(-6, 7):
                            cand = pitch + offset
                            if cand % 12 == tgt:
                                if abs(offset) < best_dist:
                                    best_dist = abs(offset)
                                    best_pitch = cand
                    pitch = best_pitch

                # 再檢查音域
                if pitch_low is not None and pitch < pitch_low:
                    continue
                if pitch_high is not None and pitch > pitch_high:
                    continue

            n.pitch = pitch
            result.append(n)

        # 最短音長濾除
        if min_note_length > 0:
            result = [n for n in result if (n.end - n.start) >= min_note_length]

        # 最大同時音數（polyphony）
        if max_polyphony is not None and max_polyphony > 0:
            filtered = []
            active = []
            for n in result:
                active = [a for a in active if a.end > n.start]
                if len(active) < max_polyphony:
                    active.append(n)
                    filtered.append(n)
            result = filtered

        inst.notes = result

    pm.write(str(midi_path))
    print(f"[✔ 完成] 後處理套用於：{midi_path}")


# -------------------------------------------------------------
# 使用 FluidSynth 將 MIDI 轉成 WAV
# -------------------------------------------------------------
def synthesize_midi_to_wav(midi_path: Path) -> Optional[Path]:

    if shutil.which("fluidsynth") is None:
        print("[⚠ 警告] 找不到 fluidsynth.exe，只提供 MIDI。")
        return None

    if not SOUNDFONT_PATH.exists():
        print(f"[⚠ 警告] 找不到 SoundFont：{SOUNDFONT_PATH}，只提供 MIDI。")
        return None

    if not midi_path.exists():
        print(f"[⚠ 警告] 找不到 MIDI：{midi_path}")
        return None

    wav_path = midi_path.with_suffix(".wav")

    cmd = [
        "fluidsynth",
        "-ni",
        "-F",
        str(wav_path),
        "-r",
        "44100",
        str(SOUNDFONT_PATH),
        str(midi_path),
    ]

    print("執行指令：", " ".join(cmd))

    try:
        subprocess.run(cmd, check=True)
        print(f"[✔ 完成] 已輸出 WAV：{wav_path}")
        return wav_path
    except subprocess.CalledProcessError:
        print("[⚠ 失敗] FluidSynth 轉檔失敗。")
        return None


# -------------------------------------------------------------
# Gradio：生成 + 後處理 + WAV 轉檔
# -------------------------------------------------------------
def gradio_generate(
    max_new_tokens,
    temperature,
    top_k,
    top_p,
    max_polyphony,
    min_note_length,
    pitch_low,
    pitch_high,
    enforce_c_major,
) -> Tuple[Optional[str], str]:

    # 0 表示「不限制」
    max_polyphony = None if int(max_polyphony) <= 0 else int(max_polyphony)
    pitch_low = None if int(pitch_low) <= 0 else int(pitch_low)
    pitch_high = None if int(pitch_high) <= 0 else int(pitch_high)
    min_note_length = float(min_note_length)

    midi_path = generate_and_save_midi(
        start_tokens=None,
        max_new_tokens=int(max_new_tokens),
        temperature=float(temperature),
        top_k=int(top_k),
        top_p=float(top_p),
    )
    midi_path = Path(midi_path)

    postprocess_midi_file(
        midi_path=midi_path,
        max_polyphony=max_polyphony,
        min_note_length=min_note_length,
        pitch_low=pitch_low,
        pitch_high=pitch_high,
        enforce_c_major=bool(enforce_c_major),
    )

    wav_path = synthesize_midi_to_wav(midi_path)

    return (str(wav_path) if wav_path else None, str(midi_path))


# -------------------------------------------------------------
# Gradio UI
# -------------------------------------------------------------
def launch_app():
    with gr.Blocks() as demo:

        gr.Markdown("# 🎵 AI 音樂生成器（Transformer）")
        gr.Markdown("包含音域限制、多聲部限制、C 大調強制等後處理功能。")

        with gr.Row():
            with gr.Column():
                max_len = gr.Slider(64, 2048, value=512, step=16, label="生成長度 (max_new_tokens)")
                temp = gr.Slider(0.1, 2.0, value=1.0, step=0.05, label="Temperature")
                top_k = gr.Slider(0, 128, value=0, step=1, label="Top-k")
                top_p = gr.Slider(0.1, 1.0, value=0.95, step=0.01, label="Top-p")

                gr.Markdown("## 🎛 附加音樂條件")
                poly = gr.Slider(0, 8, value=4, step=1, label="最大同時音數（0=不限制）")
                min_len = gr.Slider(0.0, 0.5, value=0.05, step=0.01, label="最短音長（秒）")
                low = gr.Slider(0, 127, value=48, label="最低音 (0=不限制)")
                high = gr.Slider(0, 127, value=84, label="最高音 (0=不限制)")
                cmajor = gr.Checkbox(label="限制到 C 大調", value=True)

                btn = gr.Button("生成音樂")

            with gr.Column():
                audio = gr.Audio(label="WAV 音訊（若成功轉換）", type="filepath")
                midi = gr.File(label="下載 MIDI")

        btn.click(
            fn=gradio_generate,
            inputs=[max_len, temp, top_k, top_p, poly, min_len, low, high, cmajor],
            outputs=[audio, midi],
        )

    demo.launch(server_name="127.0.0.1", server_port=None)
