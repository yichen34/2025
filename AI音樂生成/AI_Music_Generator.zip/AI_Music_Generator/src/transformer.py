# transformer.py
"""
Decoder-only Transformer 語言模型，用於事件序列的音樂生成。

依賴：
- torch
- event_codec.TOTAL_TOKENS, PAD
"""

from dataclasses import dataclass
from typing import Optional

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from .event_codec import TOTAL_TOKENS, PAD


# ---------------------------
# 超參數設定（可在 main/train 覆寫）
# ---------------------------

@dataclass
class TransformerConfig:
    vocab_size: int = TOTAL_TOKENS      # token 總數
    d_model: int = 384                  # 向量維度
    n_head: int = 6                     # multi-head attention 頭數
    n_layer: int = 6                    # Transformer block 層數
    d_ff: int = 1024                    # FFN 隱藏層寬度
    max_seq_len: int = 512             # 最大序列長度
    dropout: float = 0.1


# ---------------------------
# 位置編碼（Sinusoidal）
# ---------------------------

class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 512):
        super().__init__()
        pe = torch.zeros(max_len, d_model)  # [max_len, d_model]
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)  # [max_len, 1]
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        # 偶數維使用 sin，奇數維使用 cos
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)

        pe = pe.unsqueeze(0)  # [1, max_len, d_model]
        self.register_buffer("pe", pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [batch, seq_len, d_model]
        """
        seq_len = x.size(1)
        # 廣播加上前 seq_len 個位置編碼
        x = x + self.pe[:, :seq_len, :]
        return x


# ---------------------------
# 單一 Transformer Block
# ---------------------------

class TransformerBlock(nn.Module):
    def __init__(self, config: TransformerConfig):
        super().__init__()
        self.ln1 = nn.LayerNorm(config.d_model)
        self.ln2 = nn.LayerNorm(config.d_model)

        self.attn = nn.MultiheadAttention(
            embed_dim=config.d_model,
            num_heads=config.n_head,
            dropout=config.dropout,
            batch_first=True,  # 使用 [batch, seq, dim]
        )

        self.ff = nn.Sequential(
            nn.Linear(config.d_model, config.d_ff),
            nn.ReLU(),
            nn.Linear(config.d_ff, config.d_model),
        )

        self.dropout = nn.Dropout(config.dropout)

    def forward(self, x: torch.Tensor, attn_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        # x: [batch, seq, d_model]

        # Self-Attention（含殘差＋LayerNorm）
        h = self.ln1(x)
        attn_out, _ = self.attn(
            h,
            h,
            h,
            attn_mask=attn_mask,
            need_weights=False,
        )
        x = x + self.dropout(attn_out)

        # Feed-Forward（含殘差＋LayerNorm）
        h = self.ln2(x)
        ff_out = self.ff(h)
        x = x + self.dropout(ff_out)

        return x


# ---------------------------
# 整體 Transformer LM
# ---------------------------

class TransformerLM(nn.Module):
    def __init__(self, config: TransformerConfig):
        super().__init__()

        self.config = config
        self.token_emb = nn.Embedding(config.vocab_size, config.d_model, padding_idx=PAD)
        self.pos_enc = PositionalEncoding(config.d_model, config.max_seq_len)

        self.blocks = nn.ModuleList(
            [TransformerBlock(config) for _ in range(config.n_layer)]
        )

        self.ln_f = nn.LayerNorm(config.d_model)
        self.head = nn.Linear(config.d_model, config.vocab_size, bias=False)

        self.dropout = nn.Dropout(config.dropout)

        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            nn.init.xavier_uniform_(module.weight)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def _generate_causal_mask(self, seq_len: int, device: torch.device):
        """
        建立 causal mask，避免看到未來的 token。
        回傳形狀：[seq_len, seq_len]，適用於 batch_first=True 的 MHA。
        """
        # 上三角為 1 的 mask, 允許 i >= j 的位置
        mask = torch.triu(torch.ones(seq_len, seq_len, device=device), diagonal=1)
        # 轉成 -inf / 0 的形式，1 變成 -inf，0 變成 0
        mask = mask.masked_fill(mask == 1, float("-inf"))
        return mask

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [batch, seq] 整數 token
        回傳: [batch, seq, vocab_size] logits
        """
        device = x.device
        batch_size, seq_len = x.size()

        # Token Embedding
        h = self.token_emb(x)  # [batch, seq, d_model]

        # Positional Encoding
        h = self.pos_enc(h)
        h = self.dropout(h)

        # Causal Mask
        attn_mask = self._generate_causal_mask(seq_len, device)  # [seq, seq]

        # 經過多層 Transformer Block
        for block in self.blocks:
            h = block(h, attn_mask=attn_mask)

        # Final LayerNorm + Linear Head
        h = self.ln_f(h)
        logits = self.head(h)  # [batch, seq, vocab_size]

        return logits
