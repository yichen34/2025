# train.py
"""
使用 preprocess 產生的 data/dataset.pt 訓練 TransformerLM 模型。

執行方式：
    python -m src.train
"""

import os
from pathlib import Path
from typing import List, Dict

import torch
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm

from .event_codec import PAD
from .transformer import TransformerConfig, TransformerLM


# ---------------------------
# 設定
# ---------------------------

DATASET_PATH = Path("./data/dataset.pt")
CHECKPOINT_DIR = Path("./checkpoints")
CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
MODEL_PATH = CHECKPOINT_DIR / "model_best.pth"

# 訓練超參數
MAX_SEQ_LEN = 512
BATCH_SIZE = 8
NUM_EPOCHS = 10
LEARNING_RATE = 3e-4
WEIGHT_DECAY = 1e-4
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ---------------------------
# Dataset 與 collate_fn
# ---------------------------

class SeqDataset(Dataset):
    def __init__(self, sequences: List[List[int]]):
        self.sequences = sequences

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        # 回傳 1D LongTensor
        return torch.tensor(self.sequences[idx], dtype=torch.long)


def collate_fn(batch: List[torch.Tensor], max_seq_len: int = MAX_SEQ_LEN):
    """
    將不同長度的序列 padding 到同一長度。
    """
    # 限制最長長度不得超過 max_seq_len
    lengths = [min(len(x), max_seq_len) for x in batch]
    batch_size = len(batch)
    max_len = max(lengths)

    out = torch.full((batch_size, max_len), PAD, dtype=torch.long)

    for i, seq in enumerate(batch):
        l = lengths[i]
        out[i, :l] = seq[:l]

    return out


# ---------------------------
# 訓練與驗證迴圈
# ---------------------------

def train_one_epoch(model, dataloader, optimizer, loss_fn, epoch: int):
    model.train()
    total_loss = 0.0
    num_tokens = 0

    pbar = tqdm(dataloader, desc=f"Train Epoch {epoch}")
    for x in pbar:
        x = x.to(DEVICE)  # [batch, seq]

        # 模型輸出 logits: [batch, seq, vocab]
        logits = model(x)

        # LM 任務：使用 x[:, :-1] 預測 x[:, 1:]
        logits_flat = logits[:, :-1, :].contiguous().view(-1, logits.size(-1))
        targets = x[:, 1:].contiguous().view(-1)

        loss = loss_fn(logits_flat, targets)

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        with torch.no_grad():
            total_loss += loss.item() * targets.numel()
            num_tokens += targets.numel()

        pbar.set_postfix({"loss": loss.item()})

    avg_loss = total_loss / max(1, num_tokens)
    return avg_loss


def eval_one_epoch(model, dataloader, loss_fn, epoch: int):
    model.eval()
    total_loss = 0.0
    num_tokens = 0

    with torch.no_grad():
        pbar = tqdm(dataloader, desc=f"Val   Epoch {epoch}")
        for x in pbar:
            x = x.to(DEVICE)

            logits = model(x)
            logits_flat = logits[:, :-1, :].contiguous().view(-1, logits.size(-1))
            targets = x[:, 1:].contiguous().view(-1)

            loss = loss_fn(logits_flat, targets)

            total_loss += loss.item() * targets.numel()
            num_tokens += targets.numel()

    avg_loss = total_loss / max(1, num_tokens)
    return avg_loss


# ---------------------------
# 主程式
# ---------------------------

def main():
    assert DATASET_PATH.exists(), f"找不到資料集檔案：{DATASET_PATH}，請先執行 python -m src.preprocess"

    print(f"載入資料集：{DATASET_PATH}")
    dataset_obj: Dict[str, List[List[int]]] = torch.load(DATASET_PATH)

    train_seqs = dataset_obj["train"]
    val_seqs = dataset_obj["val"]

    print(f"Train samples: {len(train_seqs)}")
    print(f"Val   samples: {len(val_seqs)}")

    train_dataset = SeqDataset(train_seqs)
    val_dataset = SeqDataset(val_seqs)

    train_loader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        collate_fn=lambda b: collate_fn(b, MAX_SEQ_LEN),
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        collate_fn=lambda b: collate_fn(b, MAX_SEQ_LEN),
    )

    # 建立模型
    config = TransformerConfig(
        max_seq_len=MAX_SEQ_LEN,
    )
    model = TransformerLM(config).to(DEVICE)

    # 損失與 optimizer
    loss_fn = torch.nn.CrossEntropyLoss(ignore_index=PAD)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY,
    )

    best_val_loss = float("inf")

    for epoch in range(1, NUM_EPOCHS + 1):
        train_loss = train_one_epoch(model, train_loader, optimizer, loss_fn, epoch)
        val_loss = eval_one_epoch(model, val_loader, loss_fn, epoch)

        print(f"[Epoch {epoch}] Train loss: {train_loss:.6f} | Val loss: {val_loss:.6f}")

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "config": config,
                },
                MODEL_PATH,
            )
            print(f"  -> 儲存更好的模型到 {MODEL_PATH}")

    print("訓練完成。")


if __name__ == "__main__":
    main()
