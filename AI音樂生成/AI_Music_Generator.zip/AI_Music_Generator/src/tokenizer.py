# tokenizer.py
"""
將 MIDI 檔案轉成事件 token 序列，並可將 token 序列轉回 MIDI。

依賴：
- pretty_midi
- event_codec.py
"""

from typing import List, Tuple
import pretty_midi
import numpy as np

from .event_codec import (
    note_on_event,
    note_off_event,
    velocity_event,
    time_shift_event,
    decode_token,
    VELOCITY_RANGE,
)


# 時間量化設定（可以依需求調整，建議與訓練時保持一致）
# TS_RES 表示每個 Time-Shift token 對應的秒數
TS_RES = 0.02  # 每個時間步約 0.02 秒（50 fps）
MAX_TIME_SHIFT_STEPS = 127  # 對應 event_codec TIME_SHIFT_RANGE-1


# ---------------------------
# Velocity 量化工具
# ---------------------------

def velocity_to_bucket(vel: int) -> int:
    """
    將 MIDI velocity (0~127) 量化到 0 ~ VELOCITY_RANGE-1
    """
    vel = max(1, min(127, vel))
    bucket = int((vel / 127) * (VELOCITY_RANGE - 1))
    return bucket


def bucket_to_velocity(bucket: int) -> int:
    """
    將 velocity bucket 還原為 MIDI velocity。
    """
    bucket = int(np.clip(bucket, 0, VELOCITY_RANGE - 1))
    vel = int((bucket / (VELOCITY_RANGE - 1)) * 127)
    vel = max(1, min(127, vel))
    return vel


# ---------------------------
# MIDI → 事件 token 序列
# ---------------------------

def midi_to_events(pm: pretty_midi.PrettyMIDI) -> List[int]:
    """
    將一個 PrettyMIDI 物件轉成事件 token 序列。
    僅保留非打擊樂器（percussion=False）的音軌。
    """

    notes = []
    for inst in pm.instruments:
        if inst.is_drum:
            continue
        for n in inst.notes:
            notes.append(n)

    if len(notes) == 0:
        return []

    # 依開始時間排序
    notes.sort(key=lambda n: n.start)

    events: List[int] = []

    # 目前時間（秒）
    cur_time = 0.0

    for note in notes:
        # 時間差轉換為 TIME_SHIFT 事件（可能多個）
        dt = max(0.0, note.start - cur_time)
        if dt > 0:
            steps = int(dt / TS_RES)
            while steps > 0:
                step = min(steps, MAX_TIME_SHIFT_STEPS)
                events.append(time_shift_event(step))
                steps -= step

        # Velocity 事件
        vel_bucket = velocity_to_bucket(note.velocity)
        events.append(velocity_event(vel_bucket))

        # Note-On 事件
        events.append(note_on_event(note.pitch))

        # Note-Off 時間使用同樣方式在之後處理
        # 這裡簡化處理：直接在結束時間插入 Note-Off
        # 我們可以用同樣邏輯再加一次時間 shift 到 note.end

        dt_off = max(0.0, note.end - note.start)
        if dt_off > 0:
            steps_off = int(dt_off / TS_RES)
            while steps_off > 0:
                step = min(steps_off, MAX_TIME_SHIFT_STEPS)
                events.append(time_shift_event(step))
                steps_off -= step

        events.append(note_off_event(note.pitch))

        # 更新目前時間
        cur_time = note.end

    return events


def midi_file_to_events(path: str) -> List[int]:
    """
    讀取檔案路徑的 MIDI 檔並轉成事件序列。
    """
    pm = pretty_midi.PrettyMIDI(path)
    return midi_to_events(pm)


# ---------------------------
# 事件 token 序列 → MIDI
# ---------------------------

def events_to_midi(tokens: List[int]) -> pretty_midi.PrettyMIDI:
    """
    將事件 token 序列轉回 PrettyMIDI。
    注意：這是簡化版本，目標是讓生成結果能聽起來合理，
    不追求與原始 MIDI 完全一致。
    """

    pm = pretty_midi.PrettyMIDI()
    inst = pretty_midi.Instrument(program=0)  # Acoustic Grand Piano

    cur_time = 0.0
    cur_vel = 80  # 預設 velocity
    active_notes = {}  # pitch -> start_time

    for t in tokens:
        etype, val = decode_token(t)

        if etype == "time_shift":
            # 將 time_shift token 轉成秒數
            shift_steps = val
            cur_time += shift_steps * TS_RES

        elif etype == "velocity":
            cur_vel = bucket_to_velocity(val)

        elif etype == "note_on":
            pitch = int(val)
            if pitch not in active_notes:
                active_notes[pitch] = cur_time

        elif etype == "note_off":
            pitch = int(val)
            if pitch in active_notes:
                start = active_notes[pitch]
                end = max(cur_time, start + TS_RES)
                note = pretty_midi.Note(
                    velocity=cur_vel,
                    pitch=pitch,
                    start=start,
                    end=end
                )
                inst.notes.append(note)
                del active_notes[pitch]

        else:
            # special / unknown token 不處理
            continue

    pm.instruments.append(inst)
    return pm


def events_to_midi_file(tokens: List[int], out_path: str):
    """
    將事件序列轉回 MIDI 檔案，儲存到指定路徑。
    """
    pm = events_to_midi(tokens)
    pm.write(out_path)


# ---------------------------
# 訓練用切片工具
# ---------------------------

def chunk_sequence(
    seq: List[int],
    max_len: int,
    stride: int
) -> List[List[int]]:
    """
    將長序列切成多個長度為 max_len 的片段，用於訓練。
    stride 表示滑動步長。
    """
    chunks = []
    n = len(seq)
    if n <= max_len:
        return [seq]

    i = 0
    while i + max_len <= n:
        chunks.append(seq[i:i + max_len])
        i += stride

    return chunks
