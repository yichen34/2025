# generate.py
"""
使用訓練好的 TransformerLM 模型生成事件序列，並轉成 MIDI 檔。

可以被其他模組（例如 Gradio 介面）呼叫，也可以直接在終端機執行：

    python -m src.generate

會在 ./output/ 資料夾中產生一個 midi 檔。
"""

from pathlib import Path
from typing import List, Optional

import torch
import torch.nn.functional as F

from .transformer import TransformerConfig, TransformerLM
from .event_codec import TOTAL_TOKENS, PAD
from .tokenizer import events_to_midi_file


# ---------------------------
# 路徑與裝置設定
# ---------------------------

CHECKPOINT_PATH = Path("./checkpoints/model_best.pth")
OUTPUT_DIR = Path("./output")

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ---------------------------
# 載入模型
# ---------------------------

def load_model(checkpoint_path: Path = CHECKPOINT_PATH) -> TransformerLM:
    """
    從 checkpoint 載入 TransformerLM 模型與設定。
    """
    assert checkpoint_path.exists(), f"找不到模型檔案：{checkpoint_path}"

    ckpt = torch.load(checkpoint_path, map_location="cpu")

    # 如果是使用 dataclass 保存 config
    config = ckpt.get("config", TransformerConfig())
    model = TransformerLM(config)
    model.load_state_dict(ckpt["model_state_dict"])
    model.to(DEVICE)
    model.eval()

    return model


# ---------------------------
# Top-k / Top-p 過濾
# ---------------------------

def top_k_top_p_filtering(
    logits: torch.Tensor,
    top_k: int = 0,
    top_p: float = 1.0,
) -> torch.Tensor:
    """
    對 logits 做 top-k / top-p 篩選，回傳處理後 logits。

    logits: [vocab_size]
    """
    logits = logits.clone()

    # Top-k
    if top_k > 0:
        top_k = min(top_k, logits.size(-1))
        values, _ = torch.topk(logits, top_k)
        min_values = values[-1]
        logits[logits < min_values] = -float("inf")

    # Top-p (nucleus sampling)
    if top_p < 1.0:
        sorted_logits, sorted_indices = torch.sort(logits, descending=True)
        probs = F.softmax(sorted_logits, dim=-1)
        cumulative_probs = torch.cumsum(probs, dim=-1)

        # 移除累積機率超過 top_p 的 token
        sorted_indices_to_remove = cumulative_probs > top_p
        # 確保至少留一個 token
        sorted_indices_to_remove[..., 0] = False

        indices_to_remove = sorted_indices[sorted_indices_to_remove]
        logits[indices_to_remove] = -float("inf")

    return logits


# ---------------------------
# 單步生成
# ---------------------------

@torch.no_grad()
def generate_tokens(
    model: TransformerLM,
    start_tokens: List[int],
    max_new_tokens: int = 512,
    temperature: float = 1.0,
    top_k: int = 0,
    top_p: float = 1.0,
) -> List[int]:
    """
    使用自回歸方式，從 start_tokens 開始生成 max_new_tokens 個 token。
    """

    model.eval()

    # 轉成 tensor
    seq = torch.tensor(start_tokens, dtype=torch.long, device=DEVICE).unsqueeze(0)  # [1, seq]

    for i in range(max_new_tokens):

        if i % 10 == 0:
            print(f"[生成中] token {i}/{max_new_tokens}")
            
        # 若長度超過模型最大序列長度，截尾（保留最新的）
        if seq.size(1) > model.config.max_seq_len:
            seq = seq[:, -model.config.max_seq_len:]

        logits = model(seq)  # [1, seq, vocab]
        # 取最後一個位置的 logits
        next_logits = logits[0, -1, :]  # [vocab]

        # 溫度
        if temperature <= 0:
            # 退化為 argmax
            next_token = torch.argmax(next_logits, dim=-1)
        else:
            next_logits = next_logits / temperature
            # top-k, top-p 過濾
            next_logits = top_k_top_p_filtering(next_logits, top_k=top_k, top_p=top_p)
            probs = F.softmax(next_logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)[0]

        # 附加到序列
        next_token = next_token.unsqueeze(0).unsqueeze(0)  # [1, 1]
        seq = torch.cat([seq, next_token], dim=1)

    # 回傳整個產生完的序列（包含起始 token）
    return seq[0].tolist()


# ---------------------------
# 封裝：直接產生 MIDI
# ---------------------------

def generate_and_save_midi(
    start_tokens: Optional[List[int]] = None,
    max_new_tokens: int = 512,
    temperature: float = 1.0,
    top_k: int = 0,
    top_p: float = 1.0,
    out_path: Optional[Path] = None,
) -> Path:
    """
    產生 token 序列並轉為 MIDI 檔案。

    回傳實際輸出的 MIDI 檔路徑。
    """
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if out_path is None:
        out_path = OUTPUT_DIR / "generated.mid"

    # 若未提供起始 token，簡單給一個隨機起點
    if start_tokens is None or len(start_tokens) == 0:
        # 最簡單：從隨機 token 開始（實務上可改為固定 seed）
        # 這裡避免用 PAD，限制在 vocab 中非 PAD 範圍
        start_tokens = [0]  # 例如用 0 (某個 note_on) 當起始

    print(f"載入模型：{CHECKPOINT_PATH}")
    model = load_model(CHECKPOINT_PATH)

    print("開始生成 token 序列...")
    tokens = generate_tokens(
        model,
        start_tokens=start_tokens,
        max_new_tokens=max_new_tokens,
        temperature=temperature,
        top_k=top_k,
        top_p=top_p,
    )

    print(f"已生成 {len(tokens)} 個 token，轉成 MIDI 檔案...")

    events_to_midi_file(tokens, str(out_path))

    print(f"已輸出 MIDI 檔案：{out_path.resolve()}")

    return out_path


# ---------------------------
# 直接從終端機執行
# ---------------------------

if __name__ == "__main__":
    # 簡單示範：使用預設參數產生一首歌
    midi_path = generate_and_save_midi(
        start_tokens=None,
        max_new_tokens=512,
        temperature=1.0,
        top_k=0,
        top_p=0.95,
        out_path=None,   # None 會輸出到 ./output/generated.mid
    )
    print(f"完成生成：{midi_path}")
