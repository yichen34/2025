# preprocess.py
"""
將 midi/ 資料夾中的 MIDI 檔轉成事件 token 序列，
切片後分成 train / val，存成 data/dataset.pt

執行方式：
    python -m src.preprocess
"""

import os
from pathlib import Path
from typing import List, Dict

import torch
import random
from tqdm import tqdm

from .tokenizer import midi_file_to_events, chunk_sequence


# ---------------------------
# 設定
# ---------------------------

# 原始 MIDI 資料夾
MIDI_DIR = Path("./midi")

# 輸出資料集路徑
DATA_DIR = Path("./data")
DATASET_PATH = DATA_DIR / "dataset.pt"

# 序列長度與切片設定
MAX_SEQ_LEN = 512     # 每個訓練樣本的最大長度
STRIDE = 256          # 滑動視窗步長（重疊區段）

# 最短事件數（太短的片段會被丟掉）
MIN_EVENTS = 64

# train / val 比例
TRAIN_RATIO = 0.9


def collect_midi_files(midi_dir: Path) -> List[Path]:
    """收集資料夾下所有 .mid / .midi 檔案"""
    files = []
    for ext in ("*.mid", "*.midi"):
        files.extend(midi_dir.rglob(ext))
    return files


def build_dataset() -> Dict[str, List[List[int]]]:
    """
    掃描 midi/ 資料夾，轉成 token 序列並切片。

    回傳:
        {
            "train": List[List[int]],
            "val": List[List[int]]
        }
    """
    assert MIDI_DIR.exists(), f"找不到 MIDI 資料夾: {MIDI_DIR}"

    midi_files = collect_midi_files(MIDI_DIR)
    if not midi_files:
        raise FileNotFoundError(f"在 {MIDI_DIR} 底下找不到任何 .mid / .midi 檔")

    print(f"找到 {len(midi_files)} 個 MIDI 檔，開始處理...")

    all_chunks: List[List[int]] = []

    for path in tqdm(midi_files):
        try:
            events = midi_file_to_events(str(path))
        except Exception as e:
            print(f"[警告] 讀取 {path} 失敗，略過。錯誤：{e}")
            continue

        if len(events) < MIN_EVENTS:
            # 太短的不要
            continue

        chunks = chunk_sequence(events, MAX_SEQ_LEN, STRIDE)
        # 避免出現長度太短的尾巴
        chunks = [c for c in chunks if len(c) >= MIN_EVENTS]

        all_chunks.extend(chunks)

    if not all_chunks:
        raise RuntimeError("處理後沒有任何有效片段，請檢查 MIDI 資料是否正常。")

    print(f"共有 {len(all_chunks)} 個序列片段，開始隨機打散並切分 train/val ...")

    random.shuffle(all_chunks)

    n_total = len(all_chunks)
    n_train = int(n_total * TRAIN_RATIO)

    train_seqs = all_chunks[:n_train]
    val_seqs = all_chunks[n_train:]

    print(f"Train: {len(train_seqs)} 個樣本")
    print(f"Val:   {len(val_seqs)} 個樣本")

    return {
        "train": train_seqs,
        "val": val_seqs,
    }


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    dataset = build_dataset()

    torch.save(dataset, DATASET_PATH)
    print(f"已將資料集存成: {DATASET_PATH.resolve()}")


if __name__ == "__main__":
    main()
