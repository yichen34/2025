# yolo11_train/train.py
from pathlib import Path
from ultralytics import YOLO

def main():
    ROOT = Path(__file__).resolve().parents[1]
    DATA = (ROOT / "data.yaml").as_posix()

    # 先用 m 版 + 高一點解析度；或換 L 版但把 imgsz 降到 832
    model = YOLO("yolo11m-seg.pt")      # 想用大模型改成 "yolo11l-seg.pt"

    results = model.train(
        data=DATA,
        imgsz=832,                       # 先 896；若 OOM -> 832；若夠可升 1024（m 版）
        epochs=400,
        batch=16,
        device=0,
        cos_lr=True,
        close_mosaic=10,
        retina_masks=True,               # 如果顯存緊，可改 False
        overlap_mask=False,
        copy_paste=0.2,
        erasing=0.2,
        hsv_s=0.6,
        hsv_v=0.5,
        auto_augment="randaugment",
        workers=0,                       # ★ Windows 最穩，避免 spawn 錯誤
        project=str(ROOT / "runs"),
        name="exp_seg_4",
        deterministic=True,
        exist_ok=False,
    )

    # 驗證 + TTA
    model.val(data=DATA, augment=True)

if __name__ == "__main__":             # ★ Windows 必備
    main()
