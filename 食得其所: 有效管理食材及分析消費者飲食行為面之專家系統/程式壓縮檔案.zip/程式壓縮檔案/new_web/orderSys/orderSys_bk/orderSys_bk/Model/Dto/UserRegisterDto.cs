﻿namespace orderSys_bk.Model.Dto
{
    public class UserRegisterDto
    {
        public string[] photos { get; set; } //照片陣列
        public string username { get; set; } //使用者名稱
        public string phone_number { get; set; } //電話號碼
    }
}
