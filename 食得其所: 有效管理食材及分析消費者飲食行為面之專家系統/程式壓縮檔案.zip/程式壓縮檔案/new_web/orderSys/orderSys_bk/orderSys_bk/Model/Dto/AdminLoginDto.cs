﻿namespace orderSys_bk.Model.Dto
{
    public class AdminLoginDto
    {
        public int account { get; set; } //帳號
        public string? password { get; set; } //密碼
    }
}
