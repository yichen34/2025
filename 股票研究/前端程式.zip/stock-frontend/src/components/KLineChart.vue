<template>
  <div ref="chartRef" class="kline-container"></div>
</template>

<script setup>
import { ref, watch, nextTick } from 'vue'
import * as echarts from 'echarts'

const props = defineProps({
  klineData: {
    type: Array,
    required: true
  }
})

const chartRef = ref(null)
let chartInstance = null

watch(() => props.klineData, async (newData) => {
  if (!newData.length) return
  await nextTick()
  renderChart()
}, { immediate: true })

function renderChart() {
  if (!chartRef.value) return
  if (!chartInstance) {
    chartInstance = echarts.init(chartRef.value)
  }

  const dates = props.klineData.map(item => item.date)
  const values = props.klineData.map(item => [
    item.open, item.close, item.low, item.high
  ])

  const option = {
    title: { text: 'K 線圖', left: 'center' },
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: dates,
      boundaryGap: false,
      min: 'dataMin',
      max: 'dataMax' // ✅ 保證最後一筆資料在最右邊顯示
    },
    yAxis: { scale: true },
    dataZoom: [
      { type: 'inside', start: 0, end: 100 }
    ],
    series: [{
      type: 'candlestick',
      data: values,
      itemStyle: {
        color: '#ec0000',
        color0: '#00da3c',
        borderColor: '#8A0000',
        borderColor0: '#008F28'
      }
    }]
  }


  chartInstance.setOption(option)
}
</script>

<style scoped>
.kline-container {
  width: 1000px;
  height: 500px;
  margin: auto;
}

</style>
