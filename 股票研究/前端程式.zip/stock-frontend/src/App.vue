<template>
  <div style="max-width: 1000px; margin: auto;">
    <h2>📈 股票查詢</h2>

    <label>股票代碼：</label>
    <input v-model="symbol" placeholder="例:2330" required />

    <h4>快速區間選擇：</h4>
    <div>
      <button @click="setRange('1w')">1週</button>
      <button @click="setRange('1m')">1個月</button>
      <button @click="setRange('6m')">半年</button>
      <button @click="setRange('1y')">1年</button>
    </div>

    <h4>或手動輸入日期查詢：</h4>
    <form @submit.prevent="fetchStockData">
      <label>起始日期：</label>
      <input type="date" v-model="start" required />
      <label>結束日期：</label>
      <input type="date" v-model="end" required />
      <button type="submit">查詢</button>
    </form>

    <h4>圖表類型：</h4>
    <div>
      <button @click="chartType = 'line'">折線圖</button>
      <button @click="chartType = 'kline'">K 線圖</button>
    </div>

    <div v-if="error" style="color:red;">{{ error }}</div>

    <canvas id="lineChart" width="1000" height="500" v-if="chartType === 'line' && chartData.length"></canvas>
    <KLineChart v-if="chartType === 'kline' && klineData && klineData.length" :klineData="klineData" />

    <!-- 🔮 股票預測（側邊或下方）：只列出有模型的清單，點一下即預測 -->
    <div class="predict-wrap">
      <aside class="predict-side">
        <h3>🔮 已訓練台股</h3>
        <div v-if="modelsLoading">清單載入中…</div>
        <div v-else-if="modelsError" class="err">{{ modelsError }}</div>
        <ul v-else class="model-list">
          <li v-for="code in models" :key="code">
            <button
              class="model-btn"
              :class="{ active: selectedModel === code }"
              @click="predictClick(code)"
            >
              {{ code }}
            </button>
          </li>
        </ul>
      </aside>

      <section class="predict-panel">
        <h3>預測結果</h3>
        <div v-if="predLoading">預測中…</div>
      <div v-else-if="predError" class="err">{{ predError }}</div>
      <div v-else-if="pred">
          <div class="row">
            <span class="chip" :class="pred.label ? 'up' : 'down'">
              {{ pred.label ? '📈 預測上漲' : '📉 預測下跌' }}
            </span>
            <span class="chip">上漲機率：{{ (pred.up_prob*100).toFixed(2) }}%</span>
            <span class="chip">下跌機率：{{ (pred.down_prob*100).toFixed(2) }}%</span>
            <span class="chip">最新資料日：{{ pred.latest_date }}</span>
          </div>

          <h4>最近 14 天收盤價</h4>
          <table class="mini">
            <thead><tr><th>日期</th><th>收盤</th></tr></thead>
            <tbody>
              <tr v-for="r in [...pred.recent].reverse()" :key="r.Date">
                <td style="text-align:left">{{ r.Date }}</td>
                <td style="text-align:right">{{ Number(r.Close ?? 0).toLocaleString('zh-TW') }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div v-else class="muted">從左側清單選一檔股票，就會顯示預測。</div>
      </section>
    </div>


    <!-- 三大法人卡片 -->
    <div class="card inst-card">
      <h3>三大法人淨買賣</h3>
      <div class="controls">
        <input v-model="instSymbol" placeholder="例:2330" @keyup.enter="fetchInst">


        <select v-model.number="instDays" title="區間" @change="fetchInst">
          <option :value="5">近5日</option>
          <option :value="10">近10日</option>  
          <option :value="15">近15日</option>
          <option :value="20">近20日</option>
          <option :value="25">近25日</option>
          <option :value="30">近30日</option>

        </select>

        <select v-model="instUnit" title="單位" @change="fetchInst">
          <option value="lot">張</option>
          <option value="share">股</option>
        </select>

        <label style="display:flex;align-items:center;gap:6px;">
          <input type="checkbox" v-model="instIncludeToday" @change="fetchInst"> 包含今天
        </label>

        <button @click="fetchInst">查詢</button>
      </div>

      <div v-if="instError" style="color:#e11d48; margin-bottom:6px;">{{ instError }}</div>

      <table v-if="instRows.length">
        <thead>
          <tr>
            <th>日期</th>
            <th>外資（{{ instUnit==='lot' ? '張' : '股' }}）</th>
            <th>投信（{{ instUnit==='lot' ? '張' : '股' }}）</th>
            <th>自營商（{{ instUnit==='lot' ? '張' : '股' }}）</th>
            <th>合計（{{ instUnit==='lot' ? '張' : '股' }}）</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in [...instRows].sort((a,b)=> b.date.localeCompare(a.date))" :key="r.date">
            <td style="text-align:left">{{ r.date }}</td>
            <td :class="numClass(r.foreign)">{{ fmt(r.foreign) }}</td>
            <td :class="numClass(r.it)">{{ fmt(r.it) }}</td>
            <td :class="numClass(r.dealer)">{{ fmt(r.dealer) }}</td>
            <td :class="numClass(r.total)">{{ fmt(r.total) }}</td>
          </tr>
        </tbody>
      </table>

      <p v-else>尚無資料（可能是假日或尚未更新）</p>
    </div>

    <!-- EPS 區塊 -->
    <section class="eps-card">
      <h3>🧾 EPS（近幾季）</h3>

      <div class="eps-row">
        <label>股票代碼：</label>
        <input v-model="symbol" placeholder="例:2330" style="max-width:200px;" />
        <label>季數：</label>
        <input type="number" v-model.number="epsQuarters" min="1" max="16" style="width:80px;" />
        <button @click="fetchEPS" :disabled="epsLoading">{{ epsLoading ? '查詢中…' : '查詢 EPS' }}</button>
        <span v-if="epsError" class="eps-error">{{ epsError }}</span>
      </div>

      <div v-if="epsLoading">載入中…</div>

      <table v-if="epsRows.length" class="eps-table">
        <thead>
          <tr>
            <th>年度</th>
            <th>季別</th>
            <th>EPS</th>
            <th>TTM（近4季合計）</th>
            <th>涵蓋期間</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(r, idx) in epsRows" :key="idx">
            <td>{{ r.year }}</td>
            <td>Q{{ r.season }}</td>
            <td>{{ r.eps == null ? '—' : Number(r.eps).toFixed(2) }}</td>
            <td>{{ r.ttm == null ? '—' : Number(r.ttm).toFixed(2) }}</td>
            <td>{{ r.range }}</td>
          </tr>
        </tbody>
      </table>

      <div v-else-if="!epsLoading && !epsError">
        目前沒有資料，請換個代碼或增加季數再試試～
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, nextTick, watch, computed, onMounted } from 'vue'
import axios from 'axios'
import Chart from 'chart.js/auto'
import zoomPlugin from 'chartjs-plugin-zoom'
import KLineChart from './components/KLineChart.vue'

Chart.register(zoomPlugin)

const API_BASE = 'http://localhost:5000'

const symbol = ref('')

const instSymbol = computed({
  get: () => symbol.value,
  set: (v) => { symbol.value = (v || '').trim() }
})
const start = ref('')
const end = ref('')
const chartType = ref('line')
const chartData = ref([])
const klineData = ref([])
const chart = ref(null)
const error = ref('')
const dates = ref([])

/* ===== EPS（單一版本） ===== */
const epsQuarters = ref(8)
const epsRows = ref([])
const epsLoading = ref(false)
const epsError = ref('')

const fetchEPS = async () => {
  epsError.value = ''
  epsRows.value = []
  const id = (symbol.value || '').trim()
  if (!id) {
    epsError.value = '請先輸入股票代碼'
    return
  }
  epsLoading.value = true
  try {
    const res = await axios.post(`${API_BASE}/api/eps`, {
      stock_id: id,
      quarters: epsQuarters.value
    })
    const items = Array.isArray(res.data?.items) ? res.data.items : []
    // 計算每列 TTM
    const ttmList = items.map((_, i) => {
      const slice = items.slice(i, i + 4).map(x => (x.eps ?? null))
      if (slice.length < 4 || slice.some(v => v === null || Number.isNaN(v))) return null
      return slice.reduce((a, b) => a + b, 0)
    })
    epsRows.value = items.map((x, i) => ({ ...x, ttm: ttmList[i] }))
  } catch (err) {
    epsError.value = err?.response?.data?.error || err?.message || 'EPS 查詢失敗'
  } finally {
    epsLoading.value = false
  }
}
/* ===== EPS 區塊結束 ===== */

const fetchStockData = async () => {
  error.value = ''
  if (!symbol.value || !start.value || !end.value) {
    error.value = '請輸入完整資料'
    return
  }

  try {
    const res = await axios.post(`${API_BASE}/api/stock`, {
      symbol: symbol.value,
      start: start.value,
      end: end.value
    })

    chartData.value = res.data.close_prices
    dates.value = res.data.dates

    await nextTick()
    if (chart.value) chart.value.destroy()

    const ctx = document.getElementById('lineChart')
    if (ctx && chartType.value === 'line') {
      chart.value = new Chart(ctx, {
        type: 'line',
        data: {
          labels: dates.value,
          datasets: [{
            label: `${symbol.value} 收盤價`,
            data: chartData.value,
            borderColor: 'blue',
            tension: 0.2
          }]
        },
        options: {
          responsive: true,
          plugins: {
            zoom: {
              pan: { enabled: true, mode: 'x' },
              zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: 'x' }
            }
          },
          scales: { x: { ticks: { maxRotation: 90, minRotation: 45 } } }
        }
      })
    }

    const klineRes = await axios.post(`${API_BASE}/api/kline`, {
      symbol: symbol.value,
      start: start.value,
      end: end.value
    })
    // 這裡要拿陣列：klineRes.data.data
    klineData.value = (klineRes.data && Array.isArray(klineRes.data.data))
      ? klineRes.data.data
      : []

  } catch (err) {
    error.value = err.response?.data?.error || '查詢失敗'
  }
}

// 切回折線圖時，如果有資料則重畫
watch(chartType, async (type) => {
  if (type === 'line' && chartData.value.length) {
    await nextTick()
    const ctx = document.getElementById('lineChart')
    if (!ctx) return
    if (chart.value) chart.value.destroy()

    chart.value = new Chart(ctx, {
      type: 'line',
      data: {
        labels: dates.value,
        datasets: [{
          label: `${symbol.value} 收盤價`,
          data: chartData.value,
          borderColor: 'blue',
          tension: 0.2
        }]
      },
      options: {
        responsive: true,
        plugins: {
          zoom: {
            pan: { enabled: true, mode: 'x' },
            zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: 'x' }
          }
        },
        scales: { x: { ticks: { maxRotation: 90, minRotation: 45 } } }
      }
    })
  }
})

const setRange = (type) => {
  const now = new Date()
  let past = new Date()
  switch (type) {
    case '1d': past.setDate(now.getDate() - 1); break
    case '1w': past.setDate(now.getDate() - 7); break
    case '1m': past.setMonth(now.getMonth() - 1); break
    case '6m': past.setMonth(now.getMonth() - 6); break
    case '1y': past.setFullYear(now.getFullYear() - 1); break
  }
  const format = (d) => d.toISOString().split('T')[0]
  start.value = format(past)
  end.value = format(now)
  fetchStockData()
}

// ====== 預測：可用模型清單 ======
const models = ref([])
const modelsLoading = ref(false)
const modelsError = ref('')

async function loadModels() {
  modelsLoading.value = true
  modelsError.value = ''
  try {
    const { data } = await axios.get(`${API_BASE}/api/predict/models`, { timeout: 10000 })
    if (!data.ok) throw new Error(data.error || '載入失敗')
    models.value = Array.isArray(data.models) ? data.models : []
  } catch (e) {
    models.value = []
    modelsError.value = e?.message || '載入可用模型清單失敗'
  } finally {
    modelsLoading.value = false
  }
}

// ====== 預測：結果狀態與呼叫 ======
const predLoading = ref(false)
const predError = ref('')
const pred = ref(null)
// 目前選中的模型（用來讓按鈕高亮）
const selectedModel = ref(null)

// 點清單某個模型就呼叫預測 API
async function predictClick(code){
  selectedModel.value = code            // ⭐ 按下就記住選中
  predLoading.value = true
  predError.value = ''
  pred.value = null
  try {
    const { data } = await axios.get(`${API_BASE}/api/predict`, { params: { stock_id: code } })
    if (!data.ok) throw new Error(data.error || 'unknown error')
    pred.value = data
  } catch (e) {
    predError.value = e?.response?.data?.error || e?.message || '預測失敗'
  } finally {
    predLoading.value = false
  }
}



async function runPredict(code){
  predLoading.value = true
  predError.value = ''
  pred.value = null
  try {
    const { data } = await axios.get(`${API_BASE}/api/predict`, { params: { stock_id: code } })
    if (!data.ok) throw new Error(data.error || 'unknown error')
    pred.value = data
  } catch (e) {
    predError.value = e?.response?.data?.error || e?.message || '預測失敗'
  } finally {
    predLoading.value = false
  }
}

// 首次載入把清單抓回來
onMounted(() => {
  loadModels()
})


// ===== 三大法人狀態 / 方法 =====
const instDays = ref(20)
const instRows = ref([])
const instError = ref('')
const instUnit = ref('lot')          // 'lot' = 張, 'share' = 股
const instIncludeToday = ref(false)  // 預設不含今日

const fmt = n => Number(n || 0).toLocaleString('zh-TW')
const numClass = n => Number(n) >= 0 ? 'pos' : 'neg'
const normalize = v => (v || '').toString().replace(/\D/g,'').slice(0,4)

async function fetchInst(){
  instError.value = ''
  const stock = normalize(instSymbol.value)
  if(!stock){ instRows.value = []; return }
  try {
    const url = `${API_BASE}/api/inst`
      + `?stock=${stock}`
      + `&days=${Number(instDays.value)}`
      + `&unit=${String(instUnit.value)}`
      + `&include_today=${instIncludeToday.value ? '1' : '0'}`
      + `&_=${Date.now()}`   // 防瀏覽器快取
    const { data } = await axios.get(url, { timeout: 15000 })
    instRows.value = data.rows || []
  } catch (err) {
    instRows.value = []
    instError.value = err?.response?.data?.error || err?.message || '三大法人查詢失敗'
    console.error('inst error:', err)
  }
}

watch([instUnit, instIncludeToday, instDays], () => {
  if ((symbol.value || '').trim()) fetchInst()
})
</script>

<style>
form input[type="date"] {
  width: 200px;
  padding: 5px;
  margin-bottom: 10px;
}
form input[type="text"] {
  width: 300px;
  padding: 5px;
  margin-bottom: 10px;
}
button {
  padding: 5px 10px;
  margin-right: 5px;
  margin-top: 5px;
}

/* EPS 樣式 */
.eps-card { padding:16px; border:1px solid #333; border-radius:12px; margin:16px 0; }
.eps-row { display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin:8px 0; }
.eps-error { color:#e11d48; margin-left:6px; }
.eps-table { width:100%; border-collapse:collapse; margin-top:8px; }
.eps-table th, .eps-table td { border:1px solid #444; padding:8px; text-align:center; }

/* 三大法人卡片 / 表格 */
.card { padding:12px; border:1px solid #eee; border-radius:12px; margin-top:12px; }
.controls{ display:flex; gap:8px; flex-wrap:wrap; margin-bottom:8px; }
.neg{ color:#1a7f37; font-weight:600; }
.pos{ color:#d1242f; font-weight:600; }
table{ width:100%; border-collapse:collapse; }
th,td{ padding:6px 8px; border-bottom:1px solid #eee; text-align:right; }
td:first-child, th:first-child{ text-align:left; }

/* 預測區塊布局：側邊清單 + 結果 */
/* === 預測區塊 (暗色主題版本) === */
.predict-wrap {
  display: flex;
  gap: 16px;
  align-items: flex-start;
  margin: 20px 0;
  flex-wrap: wrap;
}

.predict-side {
  flex: 0 0 180px;
  border: 1px solid #444;
  border-radius: 12px;
  padding: 12px;
  background-color: #1e1e1e;
  color: #eee;
  box-shadow: 0 0 8px rgba(255,255,255,0.05);
}

.predict-side h3 {
  color: #b0c9ff;
  font-weight: 600;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  gap: 4px;
}

.model-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: grid;
  grid-template-columns: 1fr;
  gap: 8px;
}

.model-btn {
  width: 100%;
  padding: 6px 8px;
  border: 1px solid #666;
  border-radius: 10px;
  background: #2a2a2a;
  color: #eee;
  cursor: pointer;
  transition: 0.15s;
}
.model-btn:hover {
  background: #3a3a3a;
  border-color: #999;
}
.model-btn:active {
  background: #505050;
}

/* 預測結果面板 */
.predict-panel {
  flex: 1 1 520px;
  border: 1px solid #444;
  border-radius: 12px;
  padding: 14px;
  background-color: #1e1e1e;
  color: #eee;
  box-shadow: 0 0 8px rgba(255,255,255,0.05);
}

.predict-panel h3 {
  color: #b0c9ff;
  margin-bottom: 10px;
}

.chip {
  padding: 6px 10px;
  border-radius: 999px;
  font-weight: 600;
  color: #fff;
  display: inline-block;
  margin: 2px 6px 6px 0;
}
.chip.down {
  background: linear-gradient(90deg, #00c853, #43a047);
}
.chip.up {
  background: linear-gradient(90deg, #e53935, #c62828);
}

table.mini {
  width: 100%;
  border-collapse: collapse;
  color: #ddd;
}
table.mini th, table.mini td {
  border-bottom: 1px solid #444;
  padding: 6px 4px;
  text-align: left;
}
table.mini th {
  color: #b0c9ff;
}
.muted {
  color: #aaa;
}
.err {
  color: #ff6b6b;
}
.model-btn.active {
  background: linear-gradient(90deg, #2962ff, #4fc3f7);
  color: #fff;
  border-color: #64b5f6;
  box-shadow: 0 0 6px rgba(100,181,246,0.6);
}
.model-btn.active:hover {
  background: linear-gradient(90deg, #1e88e5, #29b6f6);
}

/* 預測結果表格：讓第 2 欄（收盤）右對齊＋等寬數字 */
.predict-panel table.mini th:nth-child(2),
.predict-panel table.mini td:nth-child(2) {
  text-align: right;
  font-variant-numeric: tabular-nums;        /* 支援的字體用等寬數字 */
  font-feature-settings: "tnum" 1, "lnum" 1; /* 補強某些瀏覽器 */
  white-space: nowrap;
}

</style>
